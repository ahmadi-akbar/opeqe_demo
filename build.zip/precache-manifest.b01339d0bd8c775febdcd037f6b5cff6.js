self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a564d48ec9a096ac0deda7b6821181f0",
    "url": "./index.html"
  },
  {
    "revision": "0bfd3028c148a5a9ac59",
    "url": "./static/css/main.c5a0a821.chunk.css"
  },
  {
    "revision": "f4c2ed1f8c8bbfb8c552",
    "url": "./static/js/0.3be249d3.chunk.js"
  },
  {
    "revision": "00ae824e3aea385a2cdf",
    "url": "./static/js/1.364365f8.chunk.js"
  },
  {
    "revision": "8b78f0654e2b86058ae8",
    "url": "./static/js/19.2b900d19.chunk.js"
  },
  {
    "revision": "f41df38aeb3e819d583405be8f3eaa2e",
    "url": "./static/js/19.2b900d19.chunk.js.LICENSE"
  },
  {
    "revision": "cba8d79371d4de28af84",
    "url": "./static/js/2.255fae8a.chunk.js"
  },
  {
    "revision": "f9688af3523c2625d783",
    "url": "./static/js/20.4f3e01c3.chunk.js"
  },
  {
    "revision": "80b8ddadb91ee9854ca7",
    "url": "./static/js/21.2d4dc747.chunk.js"
  },
  {
    "revision": "95242ae2424785216a0e",
    "url": "./static/js/22.b840e0d4.chunk.js"
  },
  {
    "revision": "fc1f9e40b90159beb006",
    "url": "./static/js/3.b8d15c69.chunk.js"
  },
  {
    "revision": "ce8e7418362ca9173f97",
    "url": "./static/js/4.baae6b3c.chunk.js"
  },
  {
    "revision": "9339f828eaaf7837bbfd",
    "url": "./static/js/5.56504fba.chunk.js"
  },
  {
    "revision": "cffd33aa03b585b6367c",
    "url": "./static/js/FilteredItemsPage.b4d688e1.chunk.js"
  },
  {
    "revision": "5280f803aa338abaf743",
    "url": "./static/js/HomePage.2992d45c.chunk.js"
  },
  {
    "revision": "7a6a5492f95433958229",
    "url": "./static/js/ItemInstructionPage.ea83f658.chunk.js"
  },
  {
    "revision": "551d74fe7368c764b220",
    "url": "./static/js/NotFoundPage.5fd4262c.chunk.js"
  },
  {
    "revision": "a388ec68030b42ab31e2",
    "url": "./static/js/OrderHistoryPage.6c8673a9.chunk.js"
  },
  {
    "revision": "fdcd580fe742ce0a9636",
    "url": "./static/js/OrderOptionsPage.5c56640d.chunk.js"
  },
  {
    "revision": "51c3bf287c4a47792c33ce4498f11fe3",
    "url": "./static/js/OrderOptionsPage.5c56640d.chunk.js.LICENSE"
  },
  {
    "revision": "d6bbd30ff5341832854c",
    "url": "./static/js/ProfilePage.306a100a.chunk.js"
  },
  {
    "revision": "51c3bf287c4a47792c33ce4498f11fe3",
    "url": "./static/js/ProfilePage.306a100a.chunk.js.LICENSE"
  },
  {
    "revision": "48fec39c402394def02e",
    "url": "./static/js/ReservationListPage.41f405f1.chunk.js"
  },
  {
    "revision": "a6fc380a404b1e6ff6fc",
    "url": "./static/js/ReservationOptionsPage.a4047441.chunk.js"
  },
  {
    "revision": "3f245858529e9d3c1d48",
    "url": "./static/js/ShoppingCartPage.b2e53fb4.chunk.js"
  },
  {
    "revision": "574337b87b83dd854da0",
    "url": "./static/js/SignUpPage.f7962660.chunk.js"
  },
  {
    "revision": "51c3bf287c4a47792c33ce4498f11fe3",
    "url": "./static/js/SignUpPage.f7962660.chunk.js.LICENSE"
  },
  {
    "revision": "0bfd3028c148a5a9ac59",
    "url": "./static/js/main.f8ba7655.chunk.js"
  },
  {
    "revision": "51c3bf287c4a47792c33ce4498f11fe3",
    "url": "./static/js/main.f8ba7655.chunk.js.LICENSE"
  },
  {
    "revision": "03640aa3c95daf50a51b",
    "url": "./static/js/runtime-main.bb31a8ac.js"
  },
  {
    "revision": "d4396cb23ddbdaca1ae29a1d04748a32",
    "url": "./static/media/HomeHeader.d4396cb2.jpg"
  },
  {
    "revision": "db1e72b0eaa1036a16ebde21e62ea93b",
    "url": "./static/media/american-express.db1e72b0.png"
  },
  {
    "revision": "91f42da8a4c73cd24c48d12795fde403",
    "url": "./static/media/android-mobile-app-promotion.91f42da8.jpg"
  },
  {
    "revision": "e374ae720b14326ea930e037a7086df6",
    "url": "./static/media/app-store-badge.e374ae72.svg"
  },
  {
    "revision": "ebd90e958130fa06a71e80bd46b96d54",
    "url": "./static/media/dark-logo.ebd90e95.svg"
  },
  {
    "revision": "5959168c70fd4d1cb995c6304a15d26e",
    "url": "./static/media/discover.5959168c.png"
  },
  {
    "revision": "b1252c20b0690624fa287e55136047a8",
    "url": "./static/media/footerTop.b1252c20.svg"
  },
  {
    "revision": "4b2cc4bb33daddb7aa09cfbfa5146703",
    "url": "./static/media/full-mobile-app-promotion.4b2cc4bb.jpg"
  },
  {
    "revision": "13399d0a15a564723a772926964cb4d1",
    "url": "./static/media/gift-card-promotion.13399d0a.jpg"
  },
  {
    "revision": "c68e1c2faea7c511f7f5093e1997520f",
    "url": "./static/media/google-play-badge.c68e1c2f.svg"
  },
  {
    "revision": "1032cb610087a0471f00b5bcae461fe4",
    "url": "./static/media/imessage.1032cb61.svg"
  },
  {
    "revision": "82bb71dc7809f315a4792f2c4352b72f",
    "url": "./static/media/instagram.82bb71dc.svg"
  },
  {
    "revision": "82550d23a526251d85ddb6f672071c0b",
    "url": "./static/media/ios-mobile-app-promotion.82550d23.jpg"
  },
  {
    "revision": "8e8be5ed7256c80cc6c00bb3f3725857",
    "url": "./static/media/light-logo.8e8be5ed.svg"
  },
  {
    "revision": "ebd90e958130fa06a71e80bd46b96d54",
    "url": "./static/media/logo.ebd90e95.svg"
  },
  {
    "revision": "9daf436292eb2219f2ce5cb7ae8590ae",
    "url": "./static/media/person-marker.9daf4362.svg"
  },
  {
    "revision": "534327f93c0c4de1f0fb7ccd6c98f774",
    "url": "./static/media/restaurant-marker.534327f9.svg"
  },
  {
    "revision": "15ae772499285cd1361e0d4035138124",
    "url": "./static/media/trebuchet.15ae7724.woff"
  },
  {
    "revision": "9d73671424fd7a8f1114357d7eab5d69",
    "url": "./static/media/visa.9d736714.png"
  },
  {
    "revision": "a2975a4259e4cc130d9bca56f406213e",
    "url": "./static/media/whatsapp.a2975a42.svg"
  }
]);